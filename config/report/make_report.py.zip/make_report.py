from django.db.models import Q, ExpressionWrapper
from report.models import DailyReport
from user.models import DriverPayment, User, CashCategory
from order.models import Order
from django.db.models import Sum, F, Q, Count
from cash.models import Cash
from django.db.models.functions import Coalesce
import datetime
from calendar import monthrange
from django.db import models
from order.models import Order, OrderProduct, OutputProductItems
from store.models import InputProductItems
from warehouse.models import WarehouseOperationItemDetails
from config.report.big_balance import WarehouseReportService, SupplierReportService




def update_report_order_amount_and_price(year, month, day, report_id):
    print(year, month, day)
    date = datetime.datetime(year, month, day, 23, 59)

    order_counts = Order.objects.aggregate(
        total_received_count=models.Count("id", filter=models.Q(created_at__date=date)),
        total_sell_count=models.Count("id", filter=models.Q(status=4, updated_at__date=date)),
        total_cancelled_count=models.Count("id", filter=models.Q(status=5, updated_at__date=date)),
        total_send_products_count=models.Count("id", filter=models.Q(driver_shipping_start_date=date)),
    )
    order_pro = OrderProduct.objects.aggregate(
        total_sell_price=Coalesce(
            models.Sum("price", filter=models.Q(status=4, order__status=4, order__updated_at__date=date)), 0),
        total_cancelled_price=Coalesce(
            models.Sum("price", filter=models.Q(order__status=5, order__updated_at__date=date)), 0),
        total_send_products_price=Coalesce(
            models.Sum("price", filter=models.Q(order__driver_shipping_start_date=date)), 0),
    )
    report = DailyReport.objects.get(id=report_id)
    report.total_received_orders=order_counts['total_received_count']
    report.total_sold_order_quantity=order_counts['total_sell_count']
    report.total_cancelled_order_quantity=order_counts['total_cancelled_count']
    report.total_shipped_order_quantity=order_counts['total_send_products_count']

    report.total_sold_order_price=order_pro['total_sell_price']
    report.total_cancelled_order_price=order_pro['total_cancelled_price']
    report.total_shipped_order_price=order_pro['total_send_products_price']
    report.save()
    return True


# from user kimga bo'lsaham chiqim deb hissoblanadi
# to user kassir bo'lsa chiqim hissoblaniladi

def update_report_cash_amount(year, month, day, report_id):
    date = datetime.datetime(year, month, day, 23, 59)
    # shu yerda muammo bor hamma kirim hamma chiqimlarni oladi aslida balansdeb bitta kassirni kirim chiqimi hissoblaiyotgan edi
    cash = Cash.objects.filter(created_at__date=date).aggregate(
        total_cash_inflow=Coalesce(models.Sum("amount", filter=models.Q(type=1)), 0),
        total_cash_outflow=Coalesce(models.Sum("amount", filter=models.Q(type=2)), 0),
        total_cash_transfer=Coalesce(models.Sum("amount", filter=models.Q(type=3)), 0),
    )
    total_in = Cash.objects.filter(to_user__cashieruser__isnull=False, created_at__lte=date).aggregate(
        t=Coalesce(models.Sum("amount"), 0))['t']
    total_out = Cash.objects.filter(from_user__cashieruser__isnull=False, created_at__lte=date).aggregate(
        t=Coalesce(models.Sum("amount"), 0))['t']
    report = DailyReport.objects.get(id=report_id)
    report.total_cash_inflow=cash['total_cash_inflow']
    report.total_cash_outflow=cash['total_cash_outflow']
    report.total_cash_transfer=cash['total_cash_transfer']
    report.total_cash_balance=total_in-total_out
    report.save()
    return True


def update_product_price_driver_and_store(year, month, day, report_id):
    # buyerdagi kamchiliklar
    # 1. mahsulotni kirim bo'lgan kundagini hissobledi yani bir mahsulotning aynan kirim bo'lgan summada sotmatdi
    # 2. qaytib olingan mahsulotni
    date = datetime.datetime(year, month, day, 23, 59)
    # input_total = InputProductItems.objects.filter(created_at__lte=date).aggregate(t=Coalesce(Sum("price"), 0))['t']
    # out_total = OutputProductItems.objects.filter(created_at__lte=date, output_product__is_shipping=True, order_product__isnull=False).aggregate(t=Coalesce(Sum('order_product__ordered_amount'), 0)*Coalesce(Sum('order_product__input_price'), 0))['t']
    # return_amount = OrderProduct.objects.filter(order__updated_at__lte=date, status=5).aggregate(t=Coalesce(Sum('ordered_amount'), 0)*Coalesce(Sum('input_price'), 0))['t']
    # defective = OrderProduct.objects.filter(status=7, order__updated_at__lte=date).aggregate(t=Coalesce(Sum('ordered_amount'), 0)*Coalesce(Sum('input_price'), 0))['t']

    # driver_hand_product_price = OrderProduct.objects.filter(order__driver_shipping_start_date__lte=date, status__in=[4, 6]).exclude(order__status=4).aggregate(t=Coalesce(Sum('ordered_amount'), 0)*Coalesce(Sum('input_price'), 0))['t']
    
    # input_total = InputProductItems.objects.filter(created_at__lte=date).aggregate(t=Coalesce(Sum(ExpressionWrapper(F("price") * F("amount"), output_field=models.IntegerField())), 0))['t']
    # out_total = OutputProductItems.objects.filter(created_at__lte=date, output_product__is_shipping=True, order_product__isnull=False).aggregate(t=Coalesce(Sum(F('order_product__ordered_amount')*F('order_product__input_price')), 0))['t']
    # return_amount = OrderProduct.objects.filter(order__updated_at__lte=date, status=5).aggregate(t=Coalesce(Sum(F('ordered_amount')*F('input_price')), 0))['t']
    # defective = OrderProduct.objects.filter(status=7, order__updated_at__lte=date).aggregate(t=Coalesce(Sum(F('ordered_amount')*F('input_price')), 0))['t']
    
    warehouse_service = WarehouseReportService()
    warehouses_leave_products_input_price = warehouse_service.total_product_input_price_all_warehouse_date_by(date)
    
    transit_product_price = warehouse_service.total_product_input_price_all_transit

    driver_hand_product_price = OrderProduct.objects.filter(order__updated_at__lte=date, status__in=[4, 6], driver__isnull=False).exclude(order__status=4).aggregate(t=Coalesce(Sum(F('ordered_amount')*F('input_price')), 0))['t']

    # driver_hand_product_price = OrderProduct.objects.filter(status__in=[4, 6], driver__isnull=False).exclude(order__status=4).aggregate(t=Coalesce(Sum(ExpressionWrapper(F("input_price") * F("ordered_amount"), output_field=models.IntegerField())) , 0))['t'] or 0

    
    
    report = DailyReport.objects.get(id=report_id)
    report.total_product_price_in_warehouse=warehouses_leave_products_input_price
    report.total_product_price_in_drivers=driver_hand_product_price
    report.total_product_price_in_transition=transit_product_price
    
    report.save()


def update_shopkeeper_debts(year, month, day, report_id):
    # bundagi muammolar
    #  ta'minotchini oldingi qoldi'gini tekshirihsda hardoim xozir qancha qoldiq bo'lsa shuncha ko'rinadi
    date = datetime.datetime(year, month, day, 23, 59)

    total_debt_pro_price = WarehouseOperationItemDetails.objects.filter(
        # from_warehouse_operation__from_warehouse_responsible__type=5,
        # from_warehouse_operation__from_warehouse_status="2",
        # from_warehouse_operation__to_warehouse_status="2",
            warehouse_operation__action="2",
            warehouse_operation__from_warehouse_responsible__type=5,
            warehouse_operation__from_warehouse_responsible__is_active=True,
            warehouse_operation__from_warehouse_status="2",
            warehouse_operation__to_warehouse_status="2",
    ).aggregate(
        t=Coalesce(Sum(ExpressionWrapper(F("input_price") * F("amount"), output_field=models.IntegerField())), 0))[
               't'] or 0
               
    # total_debt_pro_price = InputProductItems.objects.filter(created_at__lte=date,input_product__shopkeeper__isnull=False, input_product__pay_type__in=[1, 2]).exclude(price__isnull=True).exclude(
    #         amount__isnull=True).aggregate(
    #         total_price=Coalesce(Sum(ExpressionWrapper(F("price") * F("amount"), output_field=models.IntegerField())), 0))['total_price']
    total_pay = Cash.objects.filter(id__gt=17638, to_user__type=5, to_user__is_active=True, type=2).aggregate(
    total_price=Coalesce(Sum("amount"), 0, output_field=models.IntegerField()))['total_price']

    special_fee_amount = User.objects.filter(type=5, is_active=True).aggregate(t=Coalesce(Sum('special_fee_amount'), 0))['t']

    report = DailyReport.objects.get(id=report_id)
    report.total_debt = total_pay - (special_fee_amount + total_debt_pro_price)
    report.save()


def update_drivers_debt(year, month, day, report_id):
    # bundagi muammolar
    #  ta'minotchini oldingi qoldi'gini tekshirihsda hardoim xozir qancha qoldiq bo'lsa shuncha ko'rinadi
    date = datetime.datetime(year, month, day, 23, 59)
    debt = OrderProduct.objects.filter(order__status=4, status=4,driver__isnull=False, order__updated_at__lte=date).aggregate(t=Coalesce(Sum("price"), 0))['t']

    fee_bonus = Order.objects.filter(status=4, updated_at__lte=date, driver__isnull=False, driver_is_bonus=True).aggregate(t=Coalesce(Sum("driver_bonus_amount_won"), 0))['t']

    fee = Order.objects.filter(status=4, updated_at__lte=date, driver__isnull=False).aggregate(t=Coalesce(Sum("driver_fee"), 0))['t'] + fee_bonus

    cash = Cash.objects.filter(from_user__type="2", updated_at__lte=date).aggregate(t=Coalesce(Sum("amount"), 0))['t']
    pay_old = DriverPayment.objects.filter(updated_at__lte=date).aggregate(t=Coalesce(Sum("amount"), 0))['t']
    result = debt - fee - (cash + pay_old)    
    
    
    
    report = DailyReport.objects.get(id=report_id)
    report.drivers_debts = result
    report.save()

def update_main_balance(report_id):
    report = DailyReport.objects.get(id=report_id)
    plus =  (report.total_product_price_in_warehouse + report.total_product_price_in_transition + report.total_product_price_in_drivers + int(report.drivers_debts) + report.total_cash_balance) 
    debt = report.total_debt
    if plus < debt:
        result = report.total_debt + plus
    else:
        result = plus -  abs(report.total_debt)
                # result = plus -  abs(report.total_debt) - plus

    report.main_balance = result
    report.save()
    
    
    
#     ombordagi prolar summasi
# haydovchilardagi prolar summasi
#




def get_cash_in_history(year):
    cash_in = list(CashCategory.objects.filter(cash__created_at__year=year, cash__type=1).annotate(
        jan=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=1)), 0),
        feb=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=2)), 0),
        mart=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=3)), 0),
        aprel=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=4)), 0),
        may=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=5)), 0),
        jun=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=6)), 0),
        jul=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=7)), 0),
        avg=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=8)), 0),
        sep=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=9)), 0),
        oct=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=10)), 0),
        now=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=11)), 0),
        dec=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=12)), 0),
        count=Count("cash"),
    ).filter(count__gt=0).values("id", "name", "jan", "feb", "mart", "aprel", "may", "jun","jul" ,"avg", "sep", "oct", "now", "dec", "count"))
    
    cash_in_None_category = Cash.objects.filter(created_at__year=year, category=None, type=1).aggregate(
        jan=Coalesce(Sum("amount", filter=Q(created_at__month=1)), 0),
        feb=Coalesce(Sum("amount", filter=Q(created_at__month=2)), 0),
        mart=Coalesce(Sum("amount", filter=Q(created_at__month=3)), 0),
        aprel=Coalesce(Sum("amount", filter=Q(created_at__month=4)), 0),
        may=Coalesce(Sum("amount", filter=Q(created_at__month=5)), 0),
        jun=Coalesce(Sum("amount", filter=Q(created_at__month=6)), 0),
        jul=Coalesce(Sum("amount", filter=Q(created_at__month=7)), 0),
        avg=Coalesce(Sum("amount", filter=Q(created_at__month=8)), 0),
        sep=Coalesce(Sum("amount", filter=Q(created_at__month=9)), 0),
        oct=Coalesce(Sum("amount", filter=Q(created_at__month=10)), 0),
        now=Coalesce(Sum("amount", filter=Q(created_at__month=11)), 0),
        dec=Coalesce(Sum("amount", filter=Q(created_at__month=12)), 0),
        count=Count("id"),
    )
    cash_in.append(cash_in_None_category)
    return cash_in


def get_cash_out_history(year):
    cash_out = list(CashCategory.objects.filter(cash__created_at__year=year).annotate(
        jan=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=1, cash__type=2)), 0),
        feb=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=2, cash__type=2)), 0),
        mart=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=3, cash__type=2)), 0),
        aprel=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=4, cash__type=2)), 0),
        may=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=5, cash__type=2)), 0),
        jun=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=6, cash__type=2)), 0),
        jul=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=7, cash__type=2)), 0),
        avg=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=8, cash__type=2)), 0),
        sep=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=9, cash__type=2)), 0),
        oct=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=10, cash__type=2)), 0),
        now=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=11, cash__type=2)), 0),
        dec=Coalesce(Sum("cash__amount", filter=Q(cash__created_at__month=12, cash__type=2)), 0),
        count=Count("cash", filter=Q(cash__type=2)),
    ).filter(count__gt=0).values("id", "name", "jan", "feb", "mart", "aprel", "may", "jun","jul" ,"avg", "sep", "oct", "now", "dec", "count"))
    cash_out_None_category = Cash.objects.filter(created_at__year=year, category=None, type=2).aggregate(
        jan=Coalesce(Sum("amount", filter=Q(created_at__month=1)), 0),
        feb=Coalesce(Sum("amount", filter=Q(created_at__month=2)), 0),
        mart=Coalesce(Sum("amount", filter=Q(created_at__month=3)), 0),
        aprel=Coalesce(Sum("amount", filter=Q(created_at__month=4)), 0),
        may=Coalesce(Sum("amount", filter=Q(created_at__month=5)), 0),
        jun=Coalesce(Sum("amount", filter=Q(created_at__month=6)), 0),
        jul=Coalesce(Sum("amount", filter=Q(created_at__month=7)), 0),
        avg=Coalesce(Sum("amount", filter=Q(created_at__month=8)), 0),
        sep=Coalesce(Sum("amount", filter=Q(created_at__month=9)), 0),
        oct=Coalesce(Sum("amount", filter=Q(created_at__month=10)), 0),
        now=Coalesce(Sum("amount", filter=Q(created_at__month=11)), 0),
        dec=Coalesce(Sum("amount", filter=Q(created_at__month=12)), 0),
        count=Count("id"),
    )
    cash_out.append(cash_out_None_category)
    return cash_out