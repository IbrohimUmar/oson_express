from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.db.models import Q, F
from django.shortcuts import render, redirect, get_object_or_404

from config.warehouse.services.warehouse_operation_manager import WarehouseOperationManager
from warehouse.models import WareHouse, WarehouseOperation
from store.models import Product
from django.core.cache import cache
from django.core.paginator import Paginator
from config.warehouse.permission import warehouse_permission_check
from django.db import transaction, IntegrityError



@login_required(login_url='/login')
def warehouse_operation_history(request, warehouse_id):
    if warehouse_permission_check('warehouse_operation_history',request.user, warehouse_id) is False:
        messages.error(request, "Sizga kirish uchun ruxsat yo'q")
        return redirect('home')

    warehouse = get_object_or_404(WareHouse, id=warehouse_id)
    operations = WarehouseOperation.objects.filter(Q(from_warehouse_id=warehouse_id)|
                                                  Q(to_warehouse_id=warehouse_id)).order_by("-id")
    if request.method == "POST":
        try:
            with transaction.atomic():
                r = request.POST
                user = request.user
                position = r['position']
                status = r['status']
                cancel_note = r.get('note', None)
                operation_id = r.get('operation_id')
                if operation_id is not None:
                    if position == "from":
                        operation = WarehouseOperation.objects.select_for_update().filter(id=operation_id,
                                                                                          from_warehouse_status__in=[1, 2]).first()
                    else:
                        operation = WarehouseOperation.objects.select_for_update().filter(id=operation_id,
                                                                                          to_warehouse_status='1').first()
                else:
                    operation = None
                if not operation:
                    messages.error(request, "Holatini o'zgartirib bo'lindi")
                    return redirect('warehouse_operation_history', warehouse_id)
                # # permisson check
                if not user.is_superuser:
                    if position == "from" and operation.from_warehouse is not None:
                        if operation.from_warehouse.responsible != user:
                            messages.error(request, "Sizda o'zgartirishga izn yo'q")
                            return redirect('warehouse_operation_history', warehouse_id)

                    elif position == "to" and operation.to_warehouse is not None:
                        if operation.to_warehouse.responsible != user:
                            messages.error(request, "Sizda o'zgartirishga izn yo'q")
                            return redirect('warehouse_operation_history', warehouse_id)
                    else:
                        messages.error(request, "Sizda o'zgartirishga izn yo'q")
                        return redirect('warehouse_operation_history', warehouse_id)

                operation_manager = WarehouseOperationManager()
                if position == "from":
                    if status == "2":
                        operation_manager.operation_from_warehouse_accept(operation, user)
                    if status == "3":
                        operation_manager.operation_from_warehouse_cancel(operation, user, cancel_note)
                elif position == "to":
                    if status == "2":
                        if operation.from_warehouse_status != "2":
                            messages.error(request, "Dan ombor tasdiqlamagan chiqimni")
                            return redirect('warehouse_operation_history', warehouse_id)
                        if operation.to_warehouse:
                            operation = operation_manager.operation_to_warehouse_accept(operation, user)
                        else:
                            messages.error(request, "Haydovchiga tasdiqlab bo'lmedi buyerdan")
                            return redirect('warehouse_operation_history', warehouse_id)

                    # cancel
                    if status == "3":
                        if operation.from_warehouse_status != "2":
                            messages.error(request, "Dan ombor tasdiqlamagan chiqimni")
                            return redirect('warehouse_operation_history', warehouse_id)
                        operation_manager.operation_to_warehouse_cancel(operation, user, cancel_note)


                messages.success(request, "O'zgartirildi")
                return redirect('warehouse_operation_history', warehouse_id)

        except IntegrityError as e:
            print(e)
            messages.error(request, f"Sizda hatolik {e}")
            return redirect('warehouse_operation_history', warehouse_id)

    products = cache.get_or_set("input_product_history_products", Product.objects.all())
    if request.GET.get("product", None) not in {None, "0"}:
        operations = operations.filter(WarehouseOperationItem__product_id=request.GET['product'])

    if request.GET.get("type", "0") != "0":
        query = request.GET["type"]
        operations = operations.filter(action=query)

    if request.GET.get("from_date", None) and request.GET.get("to_date", None):
        operations = operations.filter(updated_at__date__range=(request.GET['from_date'], request.GET['to_date']))

    paginator = Paginator(operations, 100)
    page_number = request.GET.get('page')
    queryset = paginator.get_page(page_number)
    return render(request, 'warehouse/operation/history.html', {"page_obj": queryset, 'products':products, 'warehouse':warehouse,"operation_types":WarehouseOperation.action_type})
