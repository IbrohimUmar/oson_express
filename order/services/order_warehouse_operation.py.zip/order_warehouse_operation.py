from config.warehouse.services import warehouse_operation_manager
from config.warehouse.services.warehouse_operation_item_manager import WarehouseOperationItemManager
from config.warehouse.services.warehouse_operation_item_details_manager import WarehouseOperationItemDetailsManager
from order.models import Order, OrderProductCollectionItem

from warehouse.models import WarehouseOperation, WareHouse, WarehouseOperationItem, WarehouseOperationItemDetails, WarehouseOperationAndOrderRelations
from config.warehouse.services.warehouse_stock_manager import WarehouseStockManager
from warehouse.models import WareHouseStock
from order.models import OrderProduct
import datetime
from django.db.models import F


class InsufficientStockError(Exception):
    def __init__(self, product_name):
        self.product_name = product_name
        super().__init__(f"{product_name} shu mahsulotdan omborda yetarli emas.")



class OrderWarehouseOperationsService:

    def _warehouse_operation_and_order_relations_get_orders_id(self, warehouse_operation):
        orders_id = list(
            WarehouseOperationAndOrderRelations.objects.filter(warehouse_operation=warehouse_operation).values_list("order_id",
                                                                                                          flat=True))
        return orders_id


    def driver_send_product_cancel(self, warehouse_operation):
        orders_id = self._warehouse_operation_and_order_relations_get_orders_id(warehouse_operation)
        Order.objects.filter(id__in=orders_id).update(status=1, is_site_change=False)


    def driver_send_product_accept(self, warehouse_operation):
        orders_id = self._warehouse_operation_and_order_relations_get_orders_id(warehouse_operation)
        Order.objects.filter(id__in=orders_id).update(status=3, is_site_change=False,
                                                      driver_shipping_start_date=datetime.datetime.today().strftime(("%Y-%m-%d")))
        OrderProduct.objects.filter(type__in=[1, 2], order_id__in=orders_id).update(status=4, amount=F("ordered_amount"))
        OrderProduct.objects.filter(type=3, order_id__in=orders_id).update(status=4)


    def driver_send_product(self,driver, order, responsible):

        order.status = 2
        order.is_site_change = False
        order.save()

        from_warehouse = WareHouse.objects.get(id=1)

        warehouse_operation_service = warehouse_operation_manager.WarehouseOperationManager()
        warehouse_operation_item_details_services = WarehouseOperationItemDetailsManager()
        warehouse_operation_item_services = WarehouseOperationItemManager()
        warehouse_stock_manager_service = WarehouseStockManager()

        warehouse_operation = warehouse_operation_service.warehouse_operation_driver_send_product_get_or_create(
            from_warehouse, driver, responsible)

        WarehouseOperationAndOrderRelations.objects.create(action=1, warehouse_operation=warehouse_operation, order=order)
        order_products = OrderProduct.objects.filter(type__in=[1, 3],order=order)

        for order_product in order_products:
            amount = order_product.ordered_amount
            if order_product.type == '3':
                amount = order_product.main_order_product.ordered_amount

            product = order_product.product
            product_variable = order_product.product_variable

            warehouse_stock = WareHouseStock.objects.select_for_update().filter(warehouse=from_warehouse,
                                                                                    product=product,
                                                                                    product_variable=product_variable,
                                                                                    amount__gte=amount).first()
            if not warehouse_stock: raise InsufficientStockError(product.name)
            warehouse_stock.amount -= amount
            warehouse_stock.save()
            warehouse_stock_manager_service.warehouse_stock_history_add(warehouse_stock, amount, responsible,
                                                                            "OrderProduct", order_product.id)

            warehouse_operation_item = warehouse_operation_item_services.operation_item_create(warehouse_operation, product, product_variable, warehouse_stock, amount)

            leave_checked_amount = amount
            for item_details in warehouse_stock.get_warehouse_operation_item_details_queryset:
                    if leave_checked_amount > 0:
                        current_leave_amount = min(item_details.leave_amount, leave_checked_amount)
                        input_price = item_details.input_price
                        warehouse_operation_item_details_services.operation_item_details_create(
                            item_details.warehouse_operation, item_details.warehouse_operation_item,
                            item_details, warehouse_stock, warehouse_operation, warehouse_operation_item, product,
                            product_variable, input_price, current_leave_amount, current_leave_amount,
                            input_price, order_product
                        )
                        item_details.leave_amount -= current_leave_amount
                        leave_checked_amount -= current_leave_amount
                        item_details.save()

